def test2():
	print("rev")
